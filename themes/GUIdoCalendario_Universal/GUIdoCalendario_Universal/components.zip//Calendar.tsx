import { useState } from "react";
import { ChevronLeft, ChevronRight, Plus, BookOpen } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";

interface Event {
  id: number;
  title: string;
  date: Date;
  color: string;
}

interface Subject {
  id: string;
  name: string;
  active: boolean;
}

export function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events] = useState<Event[]>([
    { id: 1, title: "Reunião de equipe", date: new Date(2025, 10, 18), color: "bg-blue-500" },
    { id: 2, title: "Apresentação", date: new Date(2025, 10, 20), color: "bg-purple-500" },
    { id: 3, title: "Workshop", date: new Date(2025, 10, 25), color: "bg-green-500" },
    { id: 4, title: "Deadline projeto", date: new Date(2025, 10, 14), color: "bg-red-500" },
  ]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newSubjectId, setNewSubjectId] = useState("");
  const [newSubjectName, setNewSubjectName] = useState("");

  const months = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];

  const daysOfWeek = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    return new Date(year, month, 1).getDay();
  };

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const addSubject = () => {
    if (newSubjectId.trim() && newSubjectName.trim()) {
      const subjectExists = subjects.some(s => s.id === newSubjectId.trim());
      
      if (subjectExists) {
        alert("Uma matéria com este ID já existe!");
        return;
      }

      setSubjects([...subjects, {
        id: newSubjectId.trim(),
        name: newSubjectName.trim(),
        active: true
      }]);
      setNewSubjectId("");
      setNewSubjectName("");
      setIsDialogOpen(false);
    }
  };

  const toggleSubjectActive = (subjectId: string) => {
    setSubjects(subjects.map(subject =>
      subject.id === subjectId
        ? { ...subject, active: !subject.active }
        : subject
    ));
  };

  const removeSubject = (subjectId: string) => {
    setSubjects(subjects.filter(s => s.id !== subjectId));
  };

  const isToday = (day: number) => {
    const today = new Date();
    return (
      day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear()
    );
  };

  const getEventsForDay = (day: number) => {
    return events.filter(event => {
      return (
        event.date.getDate() === day &&
        event.date.getMonth() === currentDate.getMonth() &&
        event.date.getFullYear() === currentDate.getFullYear()
      );
    });
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const days = [];

  // Adiciona dias vazios do início
  for (let i = 0; i < firstDay; i++) {
    days.push(null);
  }

  // Adiciona os dias do mês
  for (let i = 1; i <= daysInMonth; i++) {
    days.push(i);
  }

  return (
    <div className="grid lg:grid-cols-[1fr_300px] gap-6">
      {/* Calendário Principal */}
      <Card className="p-6 shadow-lg bg-slate-800 border-slate-700">
        {/* Cabeçalho */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <h2 className="text-slate-100">
              {months[currentDate.getMonth()]} {currentDate.getFullYear()}
            </h2>
            <Button onClick={goToToday} variant="outline" size="sm" className="bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600">
              Hoje
            </Button>
          </div>
          
          <div className="flex items-center gap-2">
            <Button onClick={previousMonth} variant="outline" size="icon" className="bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button onClick={nextMonth} variant="outline" size="icon" className="bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Grid do Calendário */}
        <div className="grid grid-cols-7 gap-2">
          {/* Cabeçalho dos dias da semana */}
          {daysOfWeek.map((day) => (
            <div
              key={day}
              className="text-center py-2 text-slate-400"
            >
              {day}
            </div>
          ))}

          {/* Células dos dias */}
          {days.map((day, index) => {
            const dayEvents = day ? getEventsForDay(day) : [];
            const today = day ? isToday(day) : false;

            return (
              <div
                key={index}
                className={`min-h-[100px] p-2 border rounded-lg transition-all hover:shadow-md ${
                  day ? "bg-slate-700 cursor-pointer hover:border-blue-500" : "bg-slate-900"
                } ${today ? "border-blue-500 border-2 bg-slate-600" : "border-slate-600"}`}
              >
                {day && (
                  <>
                    <div
                      className={`text-right mb-1 ${
                        today ? "text-blue-400" : "text-slate-200"
                      }`}
                    >
                      {day}
                    </div>
                    <div className="space-y-1">
                      {dayEvents.map((event) => (
                        <div
                          key={event.id}
                          className={`text-xs text-white px-2 py-1 rounded truncate ${event.color}`}
                          title={event.title}
                        >
                          {event.title}
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      {/* Painel Lateral - Próximos Eventos */}
      <div className="space-y-6">
        <Card className="p-6 shadow-lg bg-slate-800 border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-100">Próximos Eventos</h3>
            <Button size="icon" variant="outline" className="h-8 w-8 bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="space-y-3">
            {events
              .sort((a, b) => a.date.getTime() - b.date.getTime())
              .map((event) => (
                <div
                  key={event.id}
                  className="flex items-start gap-3 p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors"
                >
                  <div className={`w-3 h-3 rounded-full ${event.color} mt-1 flex-shrink-0`} />
                  <div className="flex-1 min-w-0">
                    <div className="text-slate-100 truncate">{event.title}</div>
                    <div className="text-slate-400">
                      {event.date.toLocaleDateString("pt-BR", {
                        day: "numeric",
                        month: "long",
                      })}
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </Card>

        {/* Card de Estatísticas */}
        <Card className="p-6 shadow-lg bg-slate-800 border-slate-700">
          <h3 className="text-slate-100 mb-4">Este Mês</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Total de eventos</span>
              <Badge variant="secondary" className="bg-slate-700 text-slate-200">{events.length}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Dias com eventos</span>
              <Badge variant="secondary" className="bg-slate-700 text-slate-200">
                {new Set(events.map((e) => e.date.getDate())).size}
              </Badge>
            </div>
          </div>
        </Card>

        {/* Card de Matérias */}
        <Card className="p-6 shadow-lg bg-slate-800 border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-100">Matérias</h3>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="icon" variant="outline" className="h-8 w-8 bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600">
                  <Plus className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-slate-800 border-slate-700 text-slate-100">
                <DialogHeader>
                  <DialogTitle className="text-slate-100">Adicionar Matéria</DialogTitle>
                  <DialogDescription className="text-slate-400">
                    Insira o ID e nome da matéria para adicionar ao calendário.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject-id" className="text-slate-300">ID da Matéria</Label>
                    <Input
                      id="subject-id"
                      placeholder="Ex: MAT101"
                      value={newSubjectId}
                      onChange={(e) => setNewSubjectId(e.target.value)}
                      className="bg-slate-700 border-slate-600 text-slate-100 placeholder:text-slate-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-name" className="text-slate-300">Nome da Matéria</Label>
                    <Input
                      id="subject-name"
                      placeholder="Ex: Matemática"
                      value={newSubjectName}
                      onChange={(e) => setNewSubjectName(e.target.value)}
                      className="bg-slate-700 border-slate-600 text-slate-100 placeholder:text-slate-500"
                    />
                  </div>
                  <Button onClick={addSubject} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                    Adicionar Matéria
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {subjects.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <BookOpen className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>Nenhuma matéria adicionada</p>
            </div>
          ) : (
            <div className="space-y-3">
              {subjects.map((subject) => (
                <div
                  key={subject.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className={`w-2 h-2 rounded-full ${subject.active ? 'bg-green-500' : 'bg-slate-500'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="text-slate-100 truncate">{subject.name}</div>
                      <div className="text-slate-400">{subject.id}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-slate-400">
                      {subject.active ? 'Ativa' : 'Inativa'}
                    </div>
                    <Switch
                      checked={subject.active}
                      onCheckedChange={() => toggleSubjectActive(subject.id)}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}